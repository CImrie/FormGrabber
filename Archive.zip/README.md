# FormGrabber
A tool to copy and paste bulk information between two websites - Chrome Extension
